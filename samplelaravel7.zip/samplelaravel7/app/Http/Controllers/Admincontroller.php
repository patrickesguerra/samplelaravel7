<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class Admincontroller extends Controller
{
    public function __construct(){
        $this->middleware('is_admin');
    }
    public function addpostview(){
        return view('addpostview');
    }
    public function add(Request $request){
       request()->validate([
        'title' => 'max:40|unique:post',
        'post' => 'max:400'
       ]);
       Post::create([
        'title' => request('title'),
        'post' => request('post')
       ]);
       return redirect('adminhome');
    }
    public function cancel(){
        return redirect('adminhome');
    }
    public function editpage(Post $post){
        return view('editpage',['post'=>$post]);
    }
    public function edit(Post $post){
       request()->validate([
        'title' => 'max:40|unique:post',
        'post' => 'max:400'
       ]);
       $post->update([
        'title' => request('title'),
        'post' => request('post')
       ]);
       return redirect('adminhome');
    }
    public function delete(Post $post){
        $post->delete();
        return redirect('adminhome');
    }
}
