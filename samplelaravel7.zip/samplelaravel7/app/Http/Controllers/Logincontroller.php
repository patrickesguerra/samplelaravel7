<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Logincontroller extends Controller
{
    public function loginpage(){
        return view('loginpage');
    }
    public function login(Request $request){
        request()->validate([
            'email' => 'email|exists:users,email'
           ]);
       
        if(auth()->attempt($request->only('email','password'))){
            if(auth()->user()->is_admin == 1){
                return redirect('adminhome');
                $request->session()->invalidate();
                $request->session()->regenerateToken();
            }
            else{
                return redirect('userhome');
                $request->session()->invalidate();
                $request->session()->regenerateToken();
            }
        }
        else{
            return redirect('login')->with('error','Incorrect password!');
        }
    }
    public function adminhome(){
        $data = DB::table('post')->get();
        return view('adminhome',['post'=>$data]);
    }
    public function userhome(){
        $data = DB::table('post')->get();
        return view('userhome',['post'=>$data]);
    }
}
