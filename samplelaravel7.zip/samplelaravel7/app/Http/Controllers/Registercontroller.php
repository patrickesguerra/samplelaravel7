<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class Registercontroller extends Controller
{
    public function registerpage(){
        return view('registerpage');
    }
    public function register(Request $request){
       request()->validate([
        'name' => 'max:40',
        'email' => 'email|max:40',
        'password' => 'confirmed'
       ]);
       User::create([
        'name' => request('name'),
        'email' => request('email'),
        'password' => Hash::make(request('password'))
       ]);
       return redirect('login')->with('status','Successfully registered!');
    }
}
