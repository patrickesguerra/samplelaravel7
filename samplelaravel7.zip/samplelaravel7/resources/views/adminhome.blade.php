<HTML>
    <HEAD>
    <TITLE>Admin page</TITLE>
    </HEAD>
    <BODY>
    Welcome to Admin home page!
    <a href="/addpost"><button>Add post</button></a><form method="post" action="/logout">@csrf<button>Logout</button></form><br><br>
    @foreach($post as $post)
        {{$post->title}}<br>
        {{$post->post}}<br>
        <a href="/edit/{{$post->id}}">edit</a>
        <a href="/delete/{{$post->id}}">delete</a><br><br>
    @endforeach
    
    </BODY>
    </HTML>