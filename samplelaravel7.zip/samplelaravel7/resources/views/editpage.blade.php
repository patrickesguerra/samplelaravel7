<HTML>
    <HEAD>
    <TITLE></TITLE>
    </HEAD>
    <BODY>
    Add post <br><br>
    <form method="post" action="/edit/{{$post->id}}">
    @csrf
    <input type="text" name="title" placeholder="Title" value="{{$post->title}}" @error('title') style="border-color:red" @enderror /required><br>
    @error('title') {{$message}} @enderror<br>
    <input type="text" name="post" placeholder="Write your post" value="{{$post->post}}" @error('post') style="border-color:red" @enderror /required><br>
    @error('post') {{$message}} @enderror<br>
    <input type="submit" name="submit" value="Submit">
    </form>
    <a href="/cancel"><button>Cancel</button></a><br>
    </BODY>
    </HTML>