<HTML>
    <HEAD>
    <TITLE></TITLE>
    </HEAD>
    <BODY>
    Welcome to Login page! <br><br><br>
    @if(session('error'))
        <span style="color:red;"> {{session('error')}}</span>
    @endif
    @if(session('status'))
        <span style="color:green;">{{session('status')}}</span>
    @endif
    <form method="post" action="/login">
    @csrf
    <input type="text" name="email" placeholder="Email" @error('email') style="border-color:red" @enderror /required><br>
    @error('email') {{$message}} @enderror<br>
    <input type="password" name="password" placeholder="Password" @error('password') style="border-color:red" @enderror/required><br>
    @error('password') {{$message}} @enderror<br>
    <input type="submit" name="submit" value="Login">
    </form>
    <a href="/register"><button>Register</button></a><br>
    </BODY>
    </HTML>