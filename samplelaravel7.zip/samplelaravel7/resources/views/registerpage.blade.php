<HTML>
    <HEAD>
    <TITLE></TITLE>
    </HEAD>
    <BODY>
    <form method="post" action="/register">
    @csrf
    <input type="text" name="name" placeholder="Name" @error('name') style="border-color:red" @enderror /required><br>
    @error('name') {{$message}} @enderror<br>
    <input type="text" name="email" placeholder="Email" @error('email') style="border-color:red" @enderror /required><br>
    @error('email') {{$message}} @enderror<br>
    <input type="password" name="password" placeholder="Password" @error('password') style="border-color:red" @enderror /required><br>
    @error('password') {{$message}} @enderror<br>
    <input type="password" name="password_confirmation" placeholder="Retype your password" /required><br>
    <input type="submit" name="submit" value="Register">
    </form>
    <a href="/login"><button>Login</button></a><br>
    </BODY>
    </HTML>