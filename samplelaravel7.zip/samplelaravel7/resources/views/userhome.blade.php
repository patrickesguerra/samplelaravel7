<HTML>
    <HEAD>
    <TITLE>Userhome page</TITLE>
    </HEAD>
    <BODY>
    Welcome to Userhome page!<form method="post" action="/logout">@csrf<button>Logout</button></form><br><br>
    @foreach($post as $post)
        {{$post->title}}<br>
        {{$post->post}}<br><br>
    @endforeach
    </BODY>
    </HTML>