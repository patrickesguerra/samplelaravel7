<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admincontroller;
use App\Http\Controllers\Logincontroller;
use App\Http\Controllers\Logoutcontroller;
use App\Http\Controllers\Registercontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('login',[Logincontroller::class,'loginpage'])->name('login')->middleware('guest');
Route::post('login',[Logincontroller::class,'login']);
Route::get('register',[Registercontroller::class,'registerpage'])->middleware('guest','XssSanitizer');
Route::post('register',[Registercontroller::class,'register'])->middleware('XssSanitizer');
Route::get('adminhome',[Logincontroller::class,'adminhome'])->middleware('auth','is_admin');
Route::get('userhome',[Logincontroller::class,'userhome'])->middleware('auth','is_user');
Route::get('addpost',[Admincontroller::class,'addpostview'])->middleware('XssSanitizer');
Route::post('add',[Admincontroller::class,'add'])->middleware('XssSanitizer');
Route::get('cancel',[Admincontroller::class,'cancel']);
Route::get('edit/{post}',[Admincontroller::class,'editpage'])->middleware('XssSanitizer');
Route::post('edit/{post}',[Admincontroller::class,'edit'])->middleware('XssSanitizer');
Route::get('delete/{post}',[Admincontroller::class,'delete'])->middleware('XssSanitizer');
Route::post('logout',[Logoutcontroller::class,'logout'])->middleware('auth');

