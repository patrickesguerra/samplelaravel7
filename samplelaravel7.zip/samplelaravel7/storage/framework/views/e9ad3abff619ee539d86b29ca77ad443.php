<HTML>
    <HEAD>
    <TITLE></TITLE>
    </HEAD>
    <BODY>
    Welcome to Login page! <br><br><br>
    <?php if(session('error')): ?>
        <span style="color:red;"> <?php echo e(session('error')); ?></span>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <span style="color:green;"><?php echo e(session('status')); ?></span>
    <?php endif; ?>
    <form method="post" action="/login">
    <?php echo csrf_field(); ?>
    <input type="text" name="email" placeholder="Email" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="border-color:red" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> /required><br>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br>
    <input type="password" name="password" placeholder="Password" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> style="border-color:red" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>/required><br>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br>
    <input type="submit" name="submit" value="Login">
    </form>
    <a href="/register"><button>Register</button></a><br>
    </BODY>
    </HTML><?php /**PATH C:\xampp\htdocs\samplelaravel7\resources\views/loginpage.blade.php ENDPATH**/ ?>