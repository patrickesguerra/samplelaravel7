<HTML>
    <HEAD>
    <TITLE>Admin page</TITLE>
    </HEAD>
    <BODY>
    Welcome to Admin home page!
    <a href="/addpost"><button>Add post</button></a><form method="post" action="/logout"><?php echo csrf_field(); ?><button>Logout</button></form><br><br>
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($post->title); ?><br>
        <?php echo e($post->post); ?><br>
        <a href="/edit/<?php echo e($post->id); ?>">edit</a>
        <a href="/delete/<?php echo e($post->id); ?>">delete</a><br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </BODY>
    </HTML><?php /**PATH C:\xampp\htdocs\samplelaravel7\resources\views/adminhome.blade.php ENDPATH**/ ?>