<HTML>
    <HEAD>
    <TITLE>Userhome page</TITLE>
    </HEAD>
    <BODY>
    Welcome to Userhome page!<form method="post" action="/logout"><?php echo csrf_field(); ?><button>Logout</button></form><br><br>
    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($post->title); ?><br>
        <?php echo e($post->post); ?><br><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </BODY>
    </HTML><?php /**PATH C:\xampp\htdocs\samplelaravel7\resources\views/userhome.blade.php ENDPATH**/ ?>